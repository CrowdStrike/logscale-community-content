# CrowdStrike FLTR Parser

This package provides a parser for FLTR.

# Install

This is meant to be installed in the repo for FLTR. It works for both FDR and Data Connector. 

# Changelog

- 1.2.0 
  - Initial public release. 

# Package Contents

## Parsers

This includes a parser for FLTR.

# Use Case

- SecOps
