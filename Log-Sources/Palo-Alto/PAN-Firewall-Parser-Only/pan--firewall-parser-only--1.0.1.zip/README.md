## Palo Alto Firewall

This package contains a parser for the Palo Alto firewall. 

## Release Notes

v0.1.0 
- Initial creation

## Package Contents

- Parser

## Use Case

- ITOps - used by IT operations teams to monitor IT systems and to provide investigations and root cause analysis

## Technology Vendor

Palo Alto

## Support

Package creator doesn't currently offer support for this package.